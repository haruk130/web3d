mergeInto(LibraryManager.library, {
    print: function (a) { console.log(a) }
});