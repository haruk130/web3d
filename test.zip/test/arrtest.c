void print(int num[]);

int main() {
  return 0;
}

int add(int a,int b) {
  return a+b;
}

void img(unsigned char* iarr,int x,int y) {
  for (int iy = 0; iy < y; iy++) {
      for (int ix = 0; ix < x; ix++) {
          int index = (iy*x+ix)*4; // index of position [ix,iy]
          iarr[index+0] = 200; // Red
          iarr[index+1] = 100; // Green
          iarr[index+2] = 100; // Blue
          iarr[index+3] = 250; // Alpha
      }
  }
}